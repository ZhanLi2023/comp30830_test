import functools
import traceback
from flask import g, render_template
from sqlalchemy import create_engine, text
import config
import pymysql
import pickle
from flask import Flask, request, jsonify
import json
pymysql.install_as_MySQLdb()

app = Flask(__name__)

def connect_to_database():
    engine = create_engine("mysql://{}:{}@{}:{}/{}".format(config.USER, config.PASSWORD, config.URI, config.PORT, config.DB), echo=True)
    Connection=engine.connect()
    return Connection

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = connect_to_database()
    return db

@app.teardown_appcontext
def close_connection(exception):
 db = getattr(g, '_database', None)
 if db is not None:
    db.close()

@app.route('/')
def index():
    return render_template("index.html")

@app.route("/stations")
@functools.lru_cache(maxsize=128)
def get_stations():
    engine = get_db()
    sql = "select * from station_availability;"
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(text(sql)).fetchall()
            print('#found {} stations', len(rows), rows)
            return jsonify([row._asdict() for row in rows]) # use this formula to turn the rows into a list of dicts
    except:
        print(traceback.format_exc())
        return "error in get_stations", 404

@app.route('/weekly_data')
def get_weekly_data():
    number = request.args.get('number', type=int)
    if not number:
        return "Please provide a valid station number", 400

    engine = get_db()
    sql = text("""
        SELECT all_days.day, IFNULL(AVG(available_bikes), 0) as avg_bikes
        FROM (
            SELECT 'Monday' as day
            UNION ALL SELECT 'Tuesday'
            UNION ALL SELECT 'Wednesday'
            UNION ALL SELECT 'Thursday'
            UNION ALL SELECT 'Friday'
            UNION ALL SELECT 'Saturday'
            UNION ALL SELECT 'Sunday'
        ) as all_days
        LEFT JOIN availability ON all_days.day = DAYNAME(availability.last_update) AND availability.number = :number
        GROUP BY all_days.day
        ORDER BY FIELD(all_days.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
    """)
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(sql, {'number': number}).fetchall()
            return jsonify([row._asdict() for row in rows])
    except:
        print(traceback.format_exc())
        return "error in get_weekly_data", 404


@app.route('/hourly_data')
def get_hourly_info():
    number = request.args.get('number', type=int)
    day = request.args.get('day')
    if not number or not day:
        return "Please provide a valid station number and day", 400

    engine = get_db()
    sql = text("""
        SELECT HOUR(availability.last_update) as hour, IFNULL(AVG(available_bikes), 0) as avg_bikes
        FROM availability
        WHERE availability.number = :number AND DAYNAME(availability.last_update) = :day
        GROUP BY hour
        ORDER BY hour
    """)
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(sql, {'number': number, 'day': day}).fetchall()
            return jsonify([row._asdict() for row in rows])
    except:
        print(traceback.format_exc())
        return "error in get_hourly_info_data", 404

@app.route("/prediction")
def prediction(month,day,hour,station):
    engine = create_engine("mysql://{}:{}@{}:{}/{}".format(config.USER, config.PASSWORD, config.URI, config.PORT, config.DB), echo=True)
    sql = "select * from weather ORDER BY time DESC LIMIT 1;"
    with engine.connect() as conn:
        result = conn.execute(sql)
        rows = result.fetchone()
    rows=list(rows)
    if rows[0]=="Rain":
        rows[0]=1
    elif rows[0]=="Clouds":
        rows[0]=2
    elif rows[0] == "Clear":
        rows[0] = 3
    elif rows[0] == "Mist":
        rows[0] = 4
    elif rows[0] == "Fog":
        rows[0] = 5
    elif rows[0] == "Drizzle":
        rows[0] = 6
    X_test=[[month,day,hour,rows[1],rows[6],rows[8],rows[0]]]
    with open('models/model'+str(station)+'.pkl', 'rb') as handle:
        model = pickle.load(handle)
    result = model.predict(X_test)
    result=list(result)
    return result


# cols=["month","day","hours","temp","humidity","wind_speed","weather"]
with open('model.pkl', 'rb') as handle:
    model = pickle.load(handle)

@app.route("/predict")
def predict():
    print("--------------------------------------------------")
    engine = get_db()
    sql = "select * from weather ORDER BY time DESC LIMIT 1;"
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(text(sql)).fetchall()
            rows=list(rows[0])
    except:
        print(traceback.format_exc())
    if rows[0]=="Rain":
        rows[0]=1
    elif rows[0]=="Clouds":
        rows[0]=2
    elif rows[0] == "Clear":
        rows[0] = 3
    elif rows[0] == "Mist":
        rows[0] = 4
    elif rows[0] == "Fog":
        rows[0] = 5
    elif rows[0] == "Drizzle":
        rows[0] = 6
    def weather_data():
        X=[]
        X.append(int(rows[10][5:7]))
        X.append(int(rows[10][8:10]))
        X.append(rows[1])
        X.append(rows[6])
        X.append(rows[8])
        X.append(rows[0])
        X_test=[]
        for i in range(24):
            temp=X.copy()
            temp.insert(2,i)
            X_test.append(temp)
        return X_test

    all = []
    for i in range(1,118):
        if i != 46 and i != 70 and i != 81:
            X_test=weather_data()
            for hour in X_test:
                hour.insert(0, i)
            all.append(X_test)
    print(all)
    prediction=[]
    for i in all:
        result = model.predict(i)
        result=list(result)
        prediction.append(result)
    return json.dumps(prediction)

if __name__ == '__main__':
    app.run(debug=True)


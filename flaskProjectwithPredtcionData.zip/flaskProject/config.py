URI="dublinbike.cckaxoirozab.eu-west-1.rds.amazonaws.com"
PORT=3306
DB="dublinbike"
USER="comp30830"
PASSWORD="dublinbike"
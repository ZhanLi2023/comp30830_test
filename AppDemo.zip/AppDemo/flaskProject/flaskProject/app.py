import functools
from flask import request
import traceback
from flask import Flask, g, render_template, jsonify
from sqlalchemy import create_engine, text
import config
import pymysql
pymysql.install_as_MySQLdb()

app = Flask(__name__)

def connect_to_database():
    engine = create_engine("mysql://{}:{}@{}:{}/{}".format(config.USER, config.PASSWORD, config.URI, config.PORT, config.DB), echo=True)
    Connection=engine.connect()
    return Connection

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = connect_to_database()
    return db

@app.teardown_appcontext
def close_connection(exception):
 db = getattr(g, '_database', None)
 if db is not None:
    db.close()

@app.route('/')
def index():
    return render_template("index.html")

@app.route("/stations")
@functools.lru_cache(maxsize=128)
def get_stations():
    engine = get_db()
    sql = "select * from station_availability;"
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(text(sql)).fetchall()
            print('#found {} stations', len(rows), rows)
            return jsonify([row._asdict() for row in rows]) # use this formula to turn the rows into a list of dicts
    except:
        print(traceback.format_exc())
        return "error in get_stations", 404

@app.route('/weekly_data')
def get_weekly_data():
    number = request.args.get('number', type=int)
    if not number:
        return "Please provide a valid station number", 400

    engine = get_db()
    sql = text("""
        SELECT all_days.day, IFNULL(AVG(available_bikes), 0) as avg_bikes
        FROM (
            SELECT 'Monday' as day
            UNION ALL SELECT 'Tuesday'
            UNION ALL SELECT 'Wednesday'
            UNION ALL SELECT 'Thursday'
            UNION ALL SELECT 'Friday'
            UNION ALL SELECT 'Saturday'
            UNION ALL SELECT 'Sunday'
        ) as all_days
        LEFT JOIN availability ON all_days.day = DAYNAME(availability.last_update) AND availability.number = :number
        GROUP BY all_days.day
        ORDER BY FIELD(all_days.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
    """)
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(sql, {'number': number}).fetchall()
            return jsonify([row._asdict() for row in rows])
    except:
        print(traceback.format_exc())
        return "error in get_weekly_data", 404


@app.route('/hourly_data')
def get_hourly_info():
    number = request.args.get('number', type=int)
    day = request.args.get('day')
    if not number or not day:
        return "Please provide a valid station number and day", 400

    engine = get_db()
    sql = text("""
        SELECT HOUR(availability.last_update) as hour, IFNULL(AVG(available_bikes), 0) as avg_bikes
        FROM availability
        WHERE availability.number = :number AND DAYNAME(availability.last_update) = :day
        GROUP BY hour
        ORDER BY hour
    """)
    try:
        with engine.begin() as conn:
            rows = conn.connection.execute(sql, {'number': number, 'day': day}).fetchall()
            return jsonify([row._asdict() for row in rows])
    except:
        print(traceback.format_exc())
        return "error in get_hourly_info_data", 404


if __name__ == '__main__':
    app.run(debug=True)



function createDailyButtons() {
                $("#daily-buttons").html(""); // Clear existing daily buttons
                const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                days.forEach(day => {
                $("#daily-buttons").append(`<button class="daily-button" data-day="${day}">${day}</button>`);
                });
            }

            let weeklyChart;
            let hourlyChart;

function createWeeklyChart(weeklyData) {
                const ctx = document.getElementById('weekly-chart').getContext('2d');
                if (weeklyChart) {
                    weeklyChart.destroy();
                }
                weeklyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: weeklyData.map(row => row.day),
                    datasets: [{
                        label: 'Average Bikes',
                        data: weeklyData.map(row => row.avg_bikes),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

function createHourlyChart(hourlyData, day) {
            const ctx = document.getElementById('hourly-chart').getContext('2d');
            if (hourlyChart) {
                hourlyChart.destroy();
            }
            hourlyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: hourlyData.map(row => row.hour),
                    datasets: [{
                        label: `${day} Average Bikes`,
                        data: hourlyData.map(row => row.avg_bikes),
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

function getHourlyInfo(day, stationNumber) {
            $.getJSON(`/hourly_data?number=${stationNumber}&day=${day}`, function(hourlyData) {
                createHourlyChart(hourlyData, day);
            });
        }

        $(document).ready(function() {
        // Get stations and populate the select element
        $.getJSON("/stations", function(stations) {
        $.each(stations, function(key, station) {
            $("#station-selector").append(`<option value="${station.number}">${station.name}</option>`);
        });
    });

        // Add event listener for station selection
        $("#confirm-button").on("click", function() {
        const stationNumber = $("#station-selector").val();
        if (stationNumber) {
            $.getJSON(`/weekly_data?number=${stationNumber}`, function(weeklyData) {
                createWeeklyChart(weeklyData);
            });

            createDailyButtons();

            $(".daily-button").off("click").on("click", function() {
                const day = $(this).attr("data-day");
                getHourlyInfo(day, stationNumber);
            });
            } else {
                    alert("Please select a station.");
                    }
                });
            });

var icons = {
  bicycle: {
    icon: 'https://fontawesome.com/icons/bicycle?f=classic&s=regular'
  }
};

var icons = {
  // ... (other icons)
  bicycle: {
    iconClass: 'fas fa-bicycle'
  }
};


function initMap() {
                fetch("/stations")
                .then((response) => response.json())
                .then(data => {
                    const dublin = {lat: 53.350140, lng: -6.266155};
                    map = new google.maps.Map(document.getElementById("map"), {
                    zoom: 12,
                    center: dublin,
                });

            const infowindow = new google.maps.InfoWindow();
            console.log(data)

                    for (const station of data) {
                        var marker = new google.maps.Marker({
                            position: {
                                lat: station.position_lat, lng: station.position_lng
                            },
                            map: map,
                            title: station.name,
                        });
                        marker.addListener("click", () => {
                            const bikes = station.available_bikes;
                            const stands = station.available_bike_stations;
                            const histogramSvg = `
                            <svg width="200" height="100">
                                <rect x="10" y="10" width="${bikes * 2}" height="30" fill="rgba(75, 192, 192, 1)"></rect>
                                <rect x="10" y="50" width="${stands * 2}" height="30" fill="rgba(255, 99, 132, 1)"></rect>
                            </svg>
                            `;

                            infowindow.setContent(`<h><b>Station ${station.number}: ${station.name}</b></h><br><br>`
                            + `<p style="color: rgba(75, 192, 192, 1);"><b>Available Bikes: </b>${station.available_bikes}</p><br>`
                            + `<p style="color: rgba(255, 99, 132, 1);"><b>Available Bike Stands: </b>${station.available_bike_stations}</p><br>`
                            + histogramSvg);

                            infowindow.open(map);
                            infowindow.setPosition({lat: station.position_lat, lng: station.position_lng});
                        })
                    }


                    fetchWeatherData(53.350140, -6.266155);
                    let heatmap = null;

                    $("#heatmap-checkbox").on("change", function () {
                    if ($(this).prop("checked")) {
                        if (!heatmap) {
                        const heatmapData = data.map(station => ({
                location: new google.maps.LatLng(station.position_lat, station.position_lng),
                weight: station.available_bikes
            }));

            heatmap = new google.maps.visualization.HeatmapLayer({
                data: heatmapData,
                map: map,
                radius: 40
            });
        } else {
            heatmap.setMap(map);
        }
    } else {
        if (heatmap) {
            heatmap.setMap(null);
        }
    }
});

})
}


var map;
window.initMap=initMap;

function fetchWeatherData(lat, lon) {
                const apiKey = '582d617b5f64062c2ac443c5a5ca2f3f'; // Replace with your OpenWeatherMap API key
                const apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

                fetch(apiUrl)
                    .then((response) => response.json())
                    .then((data) => displayWeatherData(data));
            }

            function displayWeatherData(data) {
                const description = data.weather[0].description;
                const Cdescription = description.charAt(0).toUpperCase() + description.slice(1).toLowerCase();
                const temperature = data.main.temp;
                const windSpeed = data.wind.speed;

                document.getElementById('weather-description').innerText = `${Cdescription}`;
                document.getElementById('weather-temperature').innerText = `Temperature: ${temperature} °C`;
                document.getElementById('weather-humidity').innerText = `Wind Speed: ${windSpeed} m/s`;
            }

            setInterval(() => fetchWeatherData(53.350140, -6.266155), 30 * 60 * 1000);